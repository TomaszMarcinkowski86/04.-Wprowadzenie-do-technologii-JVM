public class HelloPeople {
	
	public static void main(String[] args) {
		for (String name : args) {
			System.out.println("Hello, " + name);
		}
	}
	
}